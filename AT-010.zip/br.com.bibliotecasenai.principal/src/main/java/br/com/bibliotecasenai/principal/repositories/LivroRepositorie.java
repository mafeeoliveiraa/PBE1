package br.com.bibliotecasenai.principal.repositories;

public class LivroRepositorie {

}
