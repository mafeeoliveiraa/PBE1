package com.cadastro;

public class CadastroCliente {

}
