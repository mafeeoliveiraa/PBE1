package com.senaidev.cadastroCliente.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.senaidev.cadastroCliente.Entities.Telefone;

public interface TelefoneRepository  extends JpaRepository <Telefone,Long>{

}
