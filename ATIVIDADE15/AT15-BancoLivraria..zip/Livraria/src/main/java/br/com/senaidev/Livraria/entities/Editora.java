package br.com.senaidev.Livraria.entities;

public class Editora {

}
