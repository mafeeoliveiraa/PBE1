package br.com.bibliotecasenai.usuarios;

public class Pessoa {
	//Atributos
	
		private String nome;
		private String idade;
		
		//Construtores
		public Nome() {
		public idade() {
			
			
		}
		
		public Nome(String nome){
			this.nome = nome;
		
		public Idade(String idade) {
			this.nome = nome;
		}
			//Metodos
			
			//Getters e Setters
			public void nome() {
				this.nome ++;
			}
			
			public void idade() {
				this.idade ++;
			}
			
		}

}
