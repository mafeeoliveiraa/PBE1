package br.com.bibliotecasenai.usuarios;

public class Bibliotecario extends Pessoa {
	//Atributos
	private String matricula;
	
	//Metodos
	public void realizarEmprestimo() {
		System.out.println(this.getNome() + " realizou um emprestimo");
	}
	
	public void devolverLivro() {
		System.out.println(this.getNome() + " devolveu livro");
	}

}
