package br.com.bibiotecasenai.itens;

public class Livros {
	//atributos
	private String titulo;
	private String autor;
	private int isbn;
	private boolean disponivel;
	
	//getters e setters
	
	public String getTitulo() {
		return titulo;
	}
	public void String getTitulo(String titulo) {
		this.titulo = titulo;
	}
    public String getAutor() {
    	return autor;
    }
    public void String getAutor(String autor) {
    	this.autor = autor;
    }
    public int getIsbn() {
    	return isbn;
    }
    public void setIsnb(int isbn) {
    	this.isbn = isbn;
    }
    public boolean getDisponivel() {
    	return disponivel;
    }
    public void setDisponivel(boolean disponivel) {
    	this.disponivel = disponivel;
    }
}
